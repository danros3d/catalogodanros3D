-- Ejecutar una sola vez en un proyecto Supabase nuevo.
begin;
create table public.admins (user_id uuid primary key references auth.users(id) on delete cascade);
alter table public.admins enable row level security;
revoke all on public.admins from anon, authenticated;
grant select on public.admins to authenticated;
create policy "Read own administrator membership" on public.admins for select to authenticated using (user_id = auth.uid());
create function public.is_admin() returns boolean language sql stable security definer set search_path = '' as $$ select exists(select 1 from public.admins where user_id = auth.uid()); $$;
revoke all on function public.is_admin() from public;
grant execute on function public.is_admin() to anon, authenticated;
create table public.products (
 id uuid primary key default gen_random_uuid(),
 name text not null check(length(trim(name)) between 1 and 120),
 description text not null check(length(trim(description)) between 1 and 2000),
 category text not null check(length(trim(category)) between 1 and 80),
 price numeric(9,2) not null check(price > 0),
 visible boolean not null default false,
 image_path text check(image_path is null or image_path ~ '^[a-f0-9-]{36}/[a-f0-9-]{36}\.(jpg|png|webp)$'),
 created_at timestamptz not null default now()
);
alter table public.products enable row level security;
revoke all on public.products from anon, authenticated;
grant select on public.products to anon, authenticated;
grant insert, update, delete on public.products to authenticated;
create policy "Public visible products" on public.products for select to anon, authenticated using (visible);
create policy "Administrator products" on public.products for all to authenticated using (public.is_admin()) with check (public.is_admin());
insert into storage.buckets (id,name,public,file_size_limit,allowed_mime_types) values ('product-images','product-images',true,5242880,array['image/jpeg','image/png','image/webp']);
create policy "Administrator upload" on storage.objects for insert to authenticated with check (bucket_id='product-images' and public.is_admin() and (storage.foldername(name))[1]=auth.uid()::text);
create policy "Administrator read images" on storage.objects for select to authenticated using (bucket_id='product-images' and public.is_admin());
create policy "Administrator delete images" on storage.objects for delete to authenticated using (bucket_id='product-images' and public.is_admin());
commit;
